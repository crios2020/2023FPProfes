//el nombre de la clase publica debe ser igual al nombre de archivo .java
public class Clase01 {
    //método main o método principal (main tab), escribimos todo dentro del main (Por que si!)
    public static void main(String[] args){

        // Linea de comentarios

        /*
            Bloque
            de
            comentarios
        */

        //TODO tarea pendiente  - extensión Todo Tree v0.0.226 Gruntfuggly

        //primer programa!
        System.out.println("hola mundo!");  //imprime en consola Hola mundo!
        //El lenguaje es case sensitive 
        // ; es el terminador de sentencias  
        // F5 para ejecutar(vscode)         (F8 en Ideonline)

        // syso tab, sout tab atajo de teclado para System.out.println
        System.out.println("Formación Profesional!!");
        System.out.print("1");          //Mantiene el cursos en la misma linea
        System.out.print("2");
        System.out.print("3");
        System.out.println("4");
        System.out.println("Hoy es Lunes!!!!");

        /*
         *  hola mundo!
         *  Formación Profesional!!
         *  1234
         *  Hoy es Lunes!!!!
         * 
         */

        //Uso de variables
        // Las variables son estructuras de almacenamiento en memoria RAM
        // Memoria RAM: 	Volatil		Veloz	Costosa
        // Disco Duro:	 	Persistente	Lento	Barato
		 
        // Lenguajes de tipado fuerte:  C++, Java, VsBasic, C#, TypeScript
        // Lenguajes de tipado debil:   Python, JavaScript, PHP

        //variales enteras      int 32 bits         (-4000M a 4000M)
        int a;                      //declaración de variable
        a=2;                        //asignación de valor

        int b=4;                    //declaración y asignación de variable;

        int c=a+b;                  //6

        //Una variable solo puede ser declarada una vez!
        //Una variable puede tener infinitas asignaciones de valor

        //int a=65; //Error no se puede volver a declarar a
        a=53;
        a=65;
        a=6;

        System.out.println(a);
        System.out.println("Variable a="+a);
        System.out.println("a+b="+a+b);             //a+b=64
        System.out.println("a+b="+(a+b));           //a+b=10

        //TODO Variables String        




    }

}

