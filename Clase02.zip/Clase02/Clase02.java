public class Clase02{
    public static void main(String[] args) {

        //Clase 02
        System.out.println("Clase 02 - variables");

        //Tipo de datos primitivos - Variables
        //tipo int, visto en clase01

        //Tipo de datos String
        String p="Perro";
        String l="ladra";

        System.out.println(p+l);                    //Perroladra
        System.out.println(p+" "+l);                //Perro ladra
        System.out.println(p+" que "+l);            //Perro que ladra

        // "" Shift 2 comillas doble para String en java            
        // '' comilla simple para chars en java o varchar en SQL   

        //Las cadenas de texto no se operan matematicamente
        int a=2;
        int b=4;
        String n1="2";
        String n2="4";
        System.out.println(a+b);        //6
        System.out.println(n1+n2);      //24
        System.out.println(n1+b);       //24
        System.out.println(a+n2);       //24

        //tipo de datos char    (2 bytes)  unicode
        char ch=78;
        System.out.println(ch);
        ch+=32;     //sumo 32
        System.out.println(ch);
        ch='a';
        System.out.println(ch);

        n1=ch+"";
        System.out.println(n1);


        System.out.println(n1+ch);      //concatena

        ch=176;
        System.out.println(ch);

        //tipo de datos boolean         1 byte - 8 bits
        // true=1     false=0
        boolean bo=true;        //1

        /*
                1
                -------
         */
        System.out.println(bo);
        bo=false;               //0
        System.out.println(bo);

        //Tipo de datos de punto flotante

        //Tipo de datos float(32 bits)
        float fl=9.65f;
        System.out.println(fl);

        //Tipo de datos double(64 bits)
        double dl=9.65;
        System.out.println(dl);

        fl=10;
        dl=10;
        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=100;
        dl=100;
        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=1000;
        dl=1000;
        System.out.println(fl/3);
        System.out.println(dl/3);

        //Tipo de datos long (64 bits)
        long lo=4000000000L;
        System.out.println(lo);

        //Operador de asignación =
        System.out.println("Operador de asignación =");
        int _nro1=2, $nro1=8;
        //int 1nro=1; //error

        //int nro1=5, nro2=7;
        int nro1=5;
        int nro2=7;
        System.out.println(nro1);           // 5
        System.out.println(nro2);           // 7

        nro1 = nro2;
        // <----

        System.out.println(nro1);           // 7
        System.out.println(nro2);           // 7

        //Operadores incrementales
        
        //Sumar 1 a la variable ++
        nro1++;             //nro1=nro1+1;
        System.out.println(nro1);           //8

        //Restar 1 a la variable --
        nro1--;             //nro1=nro1-1;
        System.out.println(nro1);           //7

        //Sumar 5 a la variable +=
        nro1+=5;            //nro1=nro1+5;
        System.out.println(nro1);           //12

        //Restar 5 a la variable -=
        nro1-=5;            //nro1=nro1-5   
        System.out.println(nro1);           //7

        //multiplicar 5 la variable *=
        nro1*=5;            //nro1=nro1*5
        System.out.println(nro1);           //35

        //dividir 5 la variable /=
        nro1/=5;            //nro1=nro1/5
        System.out.println(nro1);           //7

        //Operador Resto    %       
        System.out.println(25%6);       //1
        System.out.println(26%6);       //2
        System.out.println(27%6);       //3
        System.out.println(15%2);       //1
        System.out.println(14%2);       //0
        System.out.println(-14%2);      //0
        System.out.println(-15%2);      //-1

        //Uso de constantes
        //Una constante, pertenece a un tipo de datos primitivo.
        //Solo permite una asignación en el momento de declaración.
        //No se puede volver a asignar valor a una constante.
        //Los indentificadores de constante van en máyusculas
        
        //final double PI=3.14;
        final double PI=Math.PI;
        //PI++;  //Error no se puede cambiar el valor
        System.out.println(PI);

        /*
         * Desafio:
         *          - Crear la clase Triangulo, ingresar por consola base y altura y 
         *          luego calcular el perímetro y superficie de la figura.
         * 
         *          - Crear la clase Circulo, ingresar por consola el radio y
         *          luego calcular el perímetro y superficie de la figura.
         * 
         */

        //ingreso de datos por consola
        //System.out.print("Ingrese su nombre: ");
        //String nombre= new java.util.Scanner(System.in).nextLine();
        //System.out.println("Hola "+nombre);

        //Operadores Relaciones
        /*
         *  Operador        nombre
         *      ==          equals          comparación
         *      !           not
         *      !=          not equals
         *      <           menor
         *      <=          menor igual
         *      >           mayor
         *      >=          mayor igual
         */
        
        nro1=5;
        nro2=7;

        boolean log1=true;
        boolean log2=false;

        System.out.println("nro1: "+nro1);      //5
        System.out.println("nro2: "+nro2);      //7

        //Operador ==
        System.out.println(nro1==5);        //true
        System.out.println(nro1==nro2);     //false
        System.out.println(nro1+2==nro2);   //true
        System.out.println(nro1!=5);        //false
        System.out.println(nro1!=nro2);     //true
        System.out.println(nro1<=10);       //true
        System.out.println(nro1+5<10);      //false
        System.out.println(nro1+5<=10);     //true
        System.out.println(nro1>=nro2);     //false

        //Operadores Logicos
        /*
         *      Operador                nombre
         *          ||   (altGR1)       or
         *          &&   (Shift 6)      and                
         */

         //Tabla de verdad
         /*
          *         X           Y               or          and
          *         F           F               F           F
          *         F           V               V           F
          *         V           F               V           F
          *         V           V               V           V 
          */
        
        System.out.println(log1 || log2);           //true
        System.out.println(log1 && log2);           //false
        System.out.println(log2 && log1);           //false

        //Operadores binarios | or - & and
        System.out.println(log1 | log2);            //true
        System.out.println(log1 & log2);            //false
        System.out.println(log2 & log1);            //false

        //Los operadores lógicos analizan el primer termino luego el operador, si pueden dar respuesta la dan sin mirar el segundo termino
        //Los operadores binarios primero analizar los terminos y luego el operador

        //Operador not !
        System.out.println(log1);               //true
        System.out.println(!log1);              //false
        System.out.println(!!log1);             //true
        System.out.println(!!!log1);            //false
        System.out.println(!!!!log1);           //true

        System.out.println(!log1||!log2);       //true
        //                   F  or  V

        System.out.println(!log2&&nro1+2==nro2);    //true
        //                   V  Y   7    V 7

        System.out.println(!!log2&&nro1+2==nro2);    //false
        //                    F  Y                   //false

        System.out.println(!!log2 & nro1+2==nro2);        //false
        //                    F   Y      V                  //false

        System.out.println(
            !!!!!log1 || log2==log1 || nro1+2!=nro2 || (!!log1 && !!!log2 && nro1>nro2-5)
        );
        //     F      or     F      or      F       or (   V    AND  V      AND     V      )

        //TODO buscar lab de expresiones logicas

        //TODO estructuras condicionales
          

    }
}