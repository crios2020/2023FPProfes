public class Laboratorio01 {
    public static void main(String[] args) {

        /*
        Ejercicio 1 - Asignación básica
        Analice el código a continuación y complete la tabla correspondiente. 
        Luego realice la codificación
        para confirmar que ha completado la tabla correctamente.
        */

        System.out.println("A");
        int x = 10;
        int y = 20;
        System.out.println(x);
        System.out.println(y);

        System.out.println("B");
        x = x + 5;
        y = y + 10;
        System.out.println(x);
        System.out.println(y);

        System.out.println("C");
        x = x - 5;
        y = y - 10;
        System.out.println(x);
        System.out.println(y);

        System.out.println("D");
        x = x * 3;
        y = y * 5;
        System.out.println(x);
        System.out.println(y);

        System.out.println("E");
        x = x / 2;
        y = y / 4;
        System.out.println(x);
        System.out.println(y);
        
        //Tabla para completar:
        /*
                    X       Y
            A       10      20
            B       15      30
            C       10      20
            D       30      100
            E       15      25
         */

        

    }
}
