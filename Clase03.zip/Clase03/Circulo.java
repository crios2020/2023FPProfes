import java.text.DecimalFormat;
import java.util.Scanner;

public class Circulo {
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String ANSI_RESET = "\u001B[0m";
    public static void main(String[] args) {
        System.out.print(ANSI_RED+"Ingrese el radio: ");
        double radio=new Scanner(System.in).nextDouble();
        double perimetro=radio*2*Math.PI;
        //double superficie=radio*radio*Math.PI;
        double superficie=Math.pow(radio, 2)*Math.PI;

        //System.out.println("Perímetro: "+perimetro);
        //System.out.println("Superficie: "+superficie);

        //Utilidad DecimalFormat
        //DecimalFormat df=new DecimalFormat("000,000.0000");
        DecimalFormat df=new DecimalFormat("###,###.0000");
        System.out.println("Perimetro: "+df.format(perimetro));
        System.out.println("Superficie: "+df.format(superficie));


    }
}
