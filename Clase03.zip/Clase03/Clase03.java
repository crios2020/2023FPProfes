import java.util.Scanner;

public class Clase03 {
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String ANSI_RESET = "\u001B[0m";

    public static void main(String[] args) {
        /*
         * Desafio:
         * - Crear la clase Triangulo, ingresar por consola base y altura y
         * luego calcular el perímetro y superficie de la figura.
         * 
         * - Crear la clase Circulo, ingresar por consola el radio y
         * luego calcular el perímetro y superficie de la figura.
         * 
         */

        // Precedencia y procedencia de operadores unarios ++ --
        int nro1 = 4;
        System.out.println(nro1); // 4
        System.out.println(nro1++); // 4
        System.out.println(nro1); // 5
        System.out.println(++nro1); // 6

        // estructuras condicionales
        nro1 = 4;
        boolean log1 = true;

        if (log1) {
            System.out.println("Verdad 1");
            // indentado
        }

        if (nro1 == 4) {
            System.out.println("Verdad 2");
        }

        if (log1 == true) {
            System.out.println("Verdad 3");
        }

        // Uso de llaves recomendado por java
        if (log1) {
            System.out.println("Verdad 4");
        }

        // Uso de llaves recomendado por microsoft
        if (log1) 
        {
            System.out.println("Verdad 5");
        }

        // Uso de llaves abreviado in line
        if(log1) System.out.println("Verdad 6");

        boolean plata = false;
        if (plata) {
            System.out.println("Voy a Europa!!");
            System.out.println("Eurodisney!");
        }

        boolean llueve = false;
        if (llueve) {
            System.out.println(ANSI_RED);
            System.out.println("************************************");
            System.out.println("           LLUEVE !!!               ");
            System.out.println("************************************");
            System.out.println(ANSI_RESET);
        }

        //Estructura if else
        if(!log1){
            System.out.println("Verdad 7");
        }else{
            System.out.println("Falso 7");
        }

        //uso de llaves Recomendado por Microsoft
        if(!log1)
        {
            System.out.println("Verdad 8");
        }
        else
        {
            System.out.println("Falso 8");
        }
        
        //uso de llaves Abreviado
        if(!log1)       System.out.println("Verdad 9");
        else            System.out.println("Falso 9");

        //Estructura switch
        nro1=11;
        System.out.println(nro1);
        switch (nro1) {
            case 1:     System.out.println("Valor 1");      break;
            case 2:     System.out.println("Valor 2");      break;
            case 3:     System.out.println("Valor 3");      break;
            case 4:     System.out.println("Valor 4");  
            case 5:     System.out.println("Valor 5"); 
            case 6:     System.out.println("Valor 6");      break;
            case 7: case 8: case 9: case 10:
                        System.out.println("Valor entre 7 y 10");   break;      
            case 11:    System.out.println("Valor 11");     
                        System.out.println("Valor mayor de 10");
                    break;
            default:    System.out.println("El valor es otro");     break; //default no obligatorio
        }

        System.out.print(ANSI_BLUE+"Ingrese su edad: ");
        int edad=new Scanner(System.in).nextInt();
        if(edad>18){
            System.out.println(ANSI_GREEN+"Usted es mayor de edad!");
        }else{
            System.out.println(ANSI_RED+"Usted es menor de edad!");
        }
        System.out.println(ANSI_RESET);

        

    }
}