import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class Fecha {
    public static void main(String[] args) {
        Date date=new Date();                   //JDK 1
        System.out.println(date);

        Calendar calendar=Calendar.getInstance();    //JDK 1.1
        System.out.println(calendar);

        //String zona=calendar.getTimeZone().getID();

        System.out.println(
                            calendar
                                    .getTimeZone()
                                    .getID()
                                    .replace("/", " ")
                                    .replace("_", " ")
                        );
    
        LocalDateTime ldt=LocalDateTime.now();          //JDK 8
        System.out.println(ldt);
    
        int anio=ldt.getYear();
        int mes=ldt.getMonthValue();
        int diaMes=ldt.getDayOfMonth();
        int diaSem=ldt.getDayOfWeek().getValue();

        System.out.println(anio);
        System.out.println(mes);
        System.out.println(diaMes);
        System.out.println(diaSem);

        String nombreDia="";
        String nombreMes="";

        switch (diaSem) {
            case 1 : nombreDia="Lunes";     break;
            case 2 : nombreDia="Martes";    break;  
            case 3 : nombreDia="Miércoles"; break;  
            case 4 : nombreDia="Jueves";    break;
            case 5 : nombreDia="Viernes";   break;
            case 6 : nombreDia="Sábado";    break;
            case 7 : nombreDia="Domingo";   break;
        }

        // if(diaSem==1)   nombreDia="Lunes";
        // if(diaSem==2)   nombreDia="Martes";
        // if(diaSem==3)   nombreDia="Miércoles";
        // if(diaSem==4)   nombreDia="Jueves";
        // if(diaSem==5)   nombreDia="Viernes";
        // if(diaSem==6)   nombreDia="Sábado";
        // if(diaSem==7)   nombreDia="Domingo";

        if(mes==1)      nombreMes="Enero";
        if(mes==2)      nombreMes="Febrero";
        if(mes==3)      nombreMes="Marzo";
        if(mes==4)      nombreMes="Abril";
        if(mes==5)      nombreMes="Mayo";
        if(mes==6)      nombreMes="Junio";
        if(mes==7)      nombreMes="Julio";
        if(mes==8)      nombreMes="Agosto";
        if(mes==9)      nombreMes="Septiembre";
        if(mes==10)     nombreMes="Octubre";
        if(mes==11)     nombreMes="Noviembre";
        if(mes==12)     nombreMes="Diciembre";

        System.out.println("Hoy es "+nombreDia+" "+diaMes+" de "+nombreMes+" de "+anio);

    }
}
