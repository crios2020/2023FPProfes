import java.util.Scanner;

public class Login {
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String ANSI_RESET = "\u001B[0m";

    public static void main(String[] args) {
        // Dado el siguiente código:
        // String usuario = "root", clave = "123";
        // Informar los siguientes casos:
        // si usuario="root" y clave="123" Informar "Bienvenido root!"
        // si usuario="root" y clave no es "123" 
        // informar "El usuario no coincide con la contraseña"
        // si el usuario no es "root" informar "El usuario no existe!"

        System.out.println(ANSI_GREEN);
        System.out.println("************************************************");
        System.out.println("           Inicio de Sessión                    ");
        System.out.println("************************************************");
        System.out.println(ANSI_BLUE);
        System.out.print("Ingrese su nombre de usuario: ");
        String usuario=new Scanner(System.in).nextLine();
        System.out.print("Ingrese su clave: ");
        String clave=new Scanner(System.in).nextLine();

        //System.out.println(usuario+" "+clave);
        //System.out.println(usuario=="root");        //== solo compara números
        //System.out.println(usuario.equals("root")); //.equals para la comparación de Strings
        //System.out.println(usuario.equalsIgnoreCase("root"));

        // if(usuario.equals("root"))
        // {
        //     if(clave.equals("123"))
        //     {
        //         System.out.println(ANSI_GREEN+"Bienvenido Usuario!");
        //     }
        //     else
        //     {
        //         System.out.println(ANSI_RED+"Clave incorrecta!");
        //     }
        // }
        // else
        // {
        //     System.out.println(ANSI_RED+"Usuario Incorrecto!");
        // }

        if(usuario.equals("root") && clave.equals("123"))   
            System.out.println(ANSI_GREEN+"Bienvenido Usuario!");

        if(usuario.equals("root") && !clave.equals("123"))  
            System.out.println(ANSI_RED+"Clave incorrecta!");

        if(!usuario.equals("root"))                         
            System.out.println(ANSI_RED+"Usuario Incorrecto!");

        System.out.println(ANSI_RESET);
    }
}
