public class Triangulo {
    public static void main(String[] args) {
        System.out.print("Ingrese la longitud de la base del triángulo: ");
        int base=new java.util.Scanner(System.in).nextInt();        //Toma por consola un valor entero
        System.out.println();

        System.out.print("Ingrese la longitud de la altura del triángulo: ");
        int altura=new java.util.Scanner(System.in).nextInt();
        System.out.println();

        //System.out.println(base+" "+altura);

        double superficie=base * altura /2;
        double perimetro=base + altura + Math.hypot(altura, base);

        System.out.println("La superficie es: "+(int)superficie);
        System.out.println("El perímetro es: "+(int)perimetro);

        
    }
}
