public class Clase04 {
    public static void main(String[] args) {

        // Clase 04 - Estructuras de repetición

        //Mirar en youtube "Homero llevame a monte Splash"

        // Estructura while
        int a = 20;
        System.out.println("-- Inicio de estructura while --");
        while (a <= 10){
            System.out.println(a);
            a++;
        }
        System.out.println("-- Fin de estructura while --");
        System.out.println(a);

        // Estructura do While
        a=20;
        System.out.println("-- Inicio de estructura do While --");
        do{
            System.out.println(a);
            a++;
        }while(a<=10);
        System.out.println("-- Fin de estructura do While --");
        System.out.println(a);

        // Estructura while
        a = 20;
        System.out.println("-- Inicio de estructura while --");
        while (a <= 10){
            System.out.println(a);
            a++;
        }
        System.out.println("-- Fin de estructura while --");
        System.out.println(a);

        // Estructura for
        System.out.println("-- Inicio de Estructura For --");
        for(int x=1; x<=10; x++){
            System.out.println(x);
        }
        System.out.println("-- Fin de estructura For --");
        //System.out.println(x);//error variable fuera de alcance (fuera de scope)
        //int x=3;

        //Recorrido for con variable global
        for(a=1; a<=10; a++){
            System.out.println(a);
        }
        System.out.println(a);

        //Loop Infinito
        // a=1;
        // while(true){
        //     System.out.println(a);
        //     a++;
        // }

        //Loop Infinito
        // a=1;
        // while(a<=10 || true){
        //     System.out.println(a);
        //     a++;
        // }

        //Loop Infinito
        // a=1;
        // while(a<=10 || a>=0){
        //     System.out.println(a);
        //     a++;
        // }

        //Loop Infinito
        // a=1;
        // while(a<=10){
        //     System.out.println(a--);
        //     a++;
        // }

        //Loop Infinito
        //a=1;
        // while(a<=10);
        // {
        //     System.out.println(a);
        //     a++;
        // }

        // omisión de parámetros en for
        //Loop infinito
        // for(;;){
        //     System.out.println("hola");
        // }

        //loop infinito
        // for(int x=1;;x++){
        //     System.out.println(x);
        // }

        //sentencias break y continue
        a=1;
        for(;;a++){
            if(a>=11)   break;        //break rompe el ciclo
            if(a==5)    continue;      //salta
            System.out.println(a);
        }

        //Cruces de variables
        int b=2;
        for(a=b; b<=10; a++){
            System.out.println(a);
            //b++;
            if(a>=11) break;
        }

        

    }
}