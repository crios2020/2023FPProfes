import java.text.DecimalFormat;
import java.time.LocalTime;

public class Reloj {
    public static void main(String[] args) {
        LocalTime lt;
        DecimalFormat df=new DecimalFormat("00");
        while(true){
            //delay(1000);
            try{ Thread.sleep(1000); }catch(Exception e){} //dormir por 1 segundo!
            lt=LocalTime.now();
            System.out.println(
                        df.format(lt.getHour())+":"+
                        df.format(lt.getMinute())+":"+
                        df.format(lt.getSecond())
                    );
        }
    }
}
