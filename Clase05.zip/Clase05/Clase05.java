import java.util.Scanner;

import javax.swing.JOptionPane;

public class Clase05{

    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String ANSI_RESET = "\u001B[0m";

    //función principal o punto de entrada
    public static void main(String[] args) {
        
        System.out.println("Clase 05 - Funciones(Métodos) y Vectores(Arrays)");

        viernes();
        viernes(ANSI_GREEN);
        viernes(ANSI_BLUE);
        viernes(ANSI_PURPLE,"Hola a todos!");
        viernes(4);         
        //viernes(cantidad:4);
        viernes(ANSI_WHITE,2);
        viernes(ANSI_CYAN);

        //System.out.print("Ingrese su nombre: ");
        //String nombre=new Scanner(System.in).nextLine();
        //viernes(ANSI_YELLOW,"Hola "+nombre);

        int resultado=sumar(2,2);
        System.out.println(resultado);

        System.out.println(sumar(65,72));

        //JOptionPane.showMessageDialog(null,"Hola a todos!");      //obsoleto

        Fecha.main(null);


    }//end main

    //función con devolución de párametros
    //void = vacio una función void no devuelve valor
    public static int sumar(int nro1, int nro2){
        return nro1+nro2;       //valor de retorno
    }

    //declaración de función o viernes
    public static void viernes() {
        System.out.print(ANSI_RED);         //hardcodeado
        System.out.println("*************************");
        System.out.println("*** Hoy es viernes!!! ***");
        System.out.println("*************************");
        System.out.println(ANSI_RESET);
    }

    //función con ingreso de parámetros
    public static void viernes(String color){      //sobrecarga de métodos
        System.out.print(color);
        System.out.println("*************************");
        System.out.println("*** Hoy es viernes!!! ***");
        System.out.println("*************************");
        System.out.println(ANSI_RESET);
    }

    public static void viernes(String color, String texto){      //sobrecarga de métodos
        System.out.print(color);
        System.out.println("*************************");
        System.out.println("*** "+texto+" ***");
        System.out.println("*************************");
        System.out.println(ANSI_RESET);
    }

    public static void viernes(int cantidad){
        System.out.print(ANSI_RED);         //hardcodeado
        System.out.println("*************************");
        for(int a=1; a<=cantidad; a++){
            System.out.println("*** Hoy es viernes!!! ***");
        }
        System.out.println("*************************");
        System.out.println(ANSI_RESET);
    }

    public static void viernes(String color, int cantidad){
        System.out.print(color);         //hardcodeado
        System.out.println("*************************");
        for(int a=1; a<=cantidad; a++){
            System.out.println("*** Hoy es viernes!!! ***");
        }
        System.out.println("*************************");
        System.out.println(ANSI_RESET);
    }



}//end class