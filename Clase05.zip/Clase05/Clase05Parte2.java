import java.util.Arrays;

public class Clase05Parte2 {
    public static void main(String[] args) {

        // vectores - Arrays

        // declaración de vectores
        int[] numeros = new int[4];
        String[] nombres = new String[4];

        // carga de valores
        numeros[0] = 1;
        nombres[0] = "Juan";
        numeros[1] = 2;
        nombres[1] = "Maria";
        numeros[2] = 3;
        nombres[2] = "Jose";
        numeros[3] = 4;
        nombres[3] = "Dario";
        // numeros[4]=5; //fuera de rango
        // nombres[4]="Mirta";

        // La primer posición tiene indice 0
        // La ultima posición tiene indice N-1

        /*
         * numeros nombres indices
         * 1 Juan 0
         * 2 Maria 1
         * 3 Jose 2
         * 4 Dario 3
         * 
         */
        System.out.println(numeros[2] + " " + nombres[2]);
        System.out.println("**************************");
        System.out.println("Longitud de numeros: " + numeros.length);
        // recorrido del vector
        for (int a = 0; a < numeros.length; a++) {
            System.out.println(numeros[a] + " " + nombres[a]);
        }

        //declaración abreviada de un vector
        //int[] vector=new int[8];
        int[] vector={26, 23, 29, 39, 38, 45, 65, 10};
        System.out.println("Longitud vector: "+vector.length);
        for(int a=0; a<vector.length; a++) System.out.println(vector[a]);

        //Sumar todas las posiciones de un vector
        //Totalizar un vector
        int suma=0;         //sumador o acumulador
        for(int a=0; a<vector.length; a++) suma+=vector[a];
        System.out.println("Total: "+suma);

        //Ordenar un vector
        Arrays.sort(vector);
        for(int a=0; a<vector.length; a++) System.out.println(vector[a]);


        //vector String[] args
        System.out.println("Longitud args: "+args.length);
        for(int a=0; a<args.length; a++){
            System.out.println(args[a]);
        }

    }
}
