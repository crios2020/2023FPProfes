import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class Fecha {
    public static void main(String[] args) {
        Date date=new Date();                   //JDK 1
        //System.out.println(date);

        Calendar calendar=Calendar.getInstance();    //JDK 1.1
        //System.out.println(calendar);

        //String zona=calendar.getTimeZone().getID();

        System.out.println(
                            calendar
                                    .getTimeZone()
                                    .getID()
                                    .replace("/", " ")
                                    .replace("_", " ")
                        );
    
        LocalDateTime ldt=LocalDateTime.now();          //JDK 8
        //System.out.println(ldt);
    
        int anio=ldt.getYear();
        int mes=ldt.getMonthValue();
        int diaMes=ldt.getDayOfMonth();
        int diaSem=ldt.getDayOfWeek().getValue();

        //System.out.println(anio);
        // System.out.println(mes);
        // System.out.println(diaMes);
        // System.out.println(diaSem);

        String[] semana={"Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"};
        String[] meses={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};

        String nombreDia=semana[diaSem-1];
        String nombreMes=meses[mes-1];

        System.out.println("Hoy es "+nombreDia+" "+diaMes+" de "+nombreMes+" de "+anio);

    }
}
