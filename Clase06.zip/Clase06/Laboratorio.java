
public class Laboratorio{
    public static void main(String[] args) {
        
		// --------------------------------------------------
		//Laboratorio Estructura de control FOR 
		// --------------------------------------------------
        
        //Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro
        
 
        //Ejercicio 2
        // Imprimir los números del 1 al 10 uno abajo del otro
        // salteando de a dos

     
        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro
   

        // Ejercicio 4
        // Imprimir la suma de números impares del 1 al 10

        
        // Ejercicio 5
        // Imprimir la suma de la multiplicación de los números del 1 al 5
        // con la resta de los números del 1 al 5


        // Ejercicio 6
        // @
        // @
        // @
        // @
        // @


        // Ejercicio bonus
        // @@@@@
      

        // Ejercicio 7
        // @
        // @@
        // @
        // @@
        // @
        


        // Ejercicio bonus
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        
              
        // Ejercicio 8
        // @
        // @@
        // @@@
        // @@@@
        // @@@@@

    
        //Ejercicio 9
        // @@@@@
        // @@@@
        // @@@
        // @@
        // @
        

    }
}