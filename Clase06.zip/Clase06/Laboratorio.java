
public class Laboratorio{
    public static void main(String[] args) {
        
		// --------------------------------------------------
		// Laboratorio Estructura de control FOR 
		// --------------------------------------------------
        
        //Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro
        System.out.println("-- Ejercicio 1 --");
        for(int a=1; a<=10; a++) System.out.println(a);
 
        //Ejercicio 2
        // Imprimir los números del 1 al 10 uno abajo del otro
        // salteando de a dos
        System.out.println("-- Ejercicio 2 --");
        for(int a=1; a<=10; a+=2) System.out.println(a);
     
        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro
        System.out.println("-- Ejercicio 3 --");
        for(int a=10; a>=1; a--) System.out.println(a);

        // Ejercicio 4
        // Imprimir la suma de números impares del 1 al 10
        System.out.println("-- Ejercicio 4 --");
        System.out.println("Total: "+(1+3+5+7+9));
        int suma=0;
        //for(int a=1; a<=10; a+=2) suma+=a;
        for(int a=1; a<=10; a++){
            if(a%2!=0) suma+=a;
        }
        System.out.println("Total: "+suma);

        // Ejercicio 5
        // Imprimir la suma de 
        // la multiplicación de los números del 1 al 5
        // con 
        // la resta de los números del 1 al 5
        //(0-1-2-3-4-5)
        //(1-2-3-4-5)

        System.out.println("-- Ejercicio 5 --");
        int resta=0;
        int multi=1;
        for(int a=1; a<=5; a++){
            multi*=a;
            resta-=a;
        }
        System.out.println("Total: "+(multi+resta));

        // Ejercicio 6
        // @
        // @
        // @
        // @
        // @
        System.out.println("-- Ejercicio 6 --");
        for(int a=1; a<=5; a++){
            System.out.println("@");
        }

        // Ejercicio bonus
        // @@@@@
        System.out.println("-- bonus 1 --");
        for(int a=1; a<=5; a++){
            System.out.print("@");
        }
        System.out.println();

        // Ejercicio 7
        // @
        // @@
        // @
        // @@
        // @
        System.out.println("-- Ejercicio 7 --");
        for(int a=1; a<=5; a++){
            if(a%2==0)  System.out.println("@@");
            else        System.out.println("@");
        }

        // Ejercicio bonus
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        System.out.println("-- bonus 2 --");
        for(int y=1; y<=5; y++){
            for(int x=1; x<=5; x++){
                System.out.print("@");
            }
            System.out.println();
        }
              
        // Ejercicio 8
        // @
        // @@
        // @@@
        // @@@@
        // @@@@@
        System.out.println("-- Ejercicio 8 --");
        for(int y=1; y<=5; y++){
            for(int x=1; x<=y; x++){
                System.out.print("@");
            }
            System.out.println();
        }
    
        //Ejercicio 9
        // @@@@@
        // @@@@
        // @@@
        // @@
        // @
        System.out.println("-- Ejercicio 9 --");
        for(int y=5; y>=1; y--){
            for(int x=1; x<=y; x++){
                System.out.print("@");
            }
            System.out.println();
        }

    }
}