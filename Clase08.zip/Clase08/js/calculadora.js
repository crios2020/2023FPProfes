//saludar("Carlos")
function saludar(nombre){
    alert("hola "+nombre)
}

function sumar(){
    numero1=parseFloat(document.getElementById("numero1").value)
    numero2=parseFloat(document.getElementById("numero2").value)
    resultado=numero1+numero2
    document.getElementById("resultado").setAttribute("value",resultado)
    
    //console.log("se ejecuto una función!")
    //console.log(numero1)
    //console.log(numero2)
    //console.log(numero1+numero2)
}

// IMC
//función calcularIMC()
//funcion obtenerEstado()
//funcion calcular() //es llamada desde el html, llama a las otras funciones y publica resultados

function restar(){
    numero1=parseFloat(document.getElementById("numero1").value)
    numero2=parseFloat(document.getElementById("numero2").value)
    resultado=numero1-numero2
    document.getElementById("resultado").setAttribute("value",resultado)
}

function multiplicar(){
    numero1=parseFloat(document.getElementById("numero1").value)
    numero2=parseFloat(document.getElementById("numero2").value)
    resultado=numero1*numero2
    document.getElementById("resultado").setAttribute("value",resultado)
}

function dividir(){
    numero1=parseFloat(document.getElementById("numero1").value)
    numero2=parseFloat(document.getElementById("numero2").value)
    if(numero2==0){
        document.getElementById("resultado").setAttribute("value","Error div/0")
    }else{
        resultado=numero1/numero2
        document.getElementById("resultado").setAttribute("value",resultado)
    }

}