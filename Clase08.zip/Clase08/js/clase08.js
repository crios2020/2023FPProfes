//lenguaje javascript
//comentarios de una linea
/* bloque de comentarios */

//lenguaje de tipado debil
var a = 2;
a = "hola";

console.log("hola mundo")

//document.writeln("hola mundo") //no se recomienda hacer

document.getElementById("control1").innerHTML = "<h1>Hoy es viernes!</h1>"
document.getElementById("control1").style = "color: blue; background-color: gray; text-align: center;"

var control2 = document.getElementById("control2")
control2.innerHTML = "<h2>Hace Calor!!!</h2>"
control2.style = "color: red; background-color: orange;"

var control3 = document.getElementById("control3")
//control3.innerHTML="<h2>Mucho Calor!!</h2>"
control3.style = "background-color:#f6c73c; color: white;"

alert("hola a todos!!")
var nombre = window.prompt("ingrese su nombre:")
control3.innerHTML = "<h2>Hola " + nombre + "</h2>"

control4 = document.getElementById("control4")
var edad = window.prompt("Ingrese su edad: ")
if (edad < 18) {
    control4.innerHTML = "<h3>Usted es menor de edad</h3>"
    control4.style = "background-color: yellow; color:red;"
} else {
    control4.innerHTML = "<h3>bienvenido</h3>"
    control4.style = "background-color: pink; color: blue;"
}