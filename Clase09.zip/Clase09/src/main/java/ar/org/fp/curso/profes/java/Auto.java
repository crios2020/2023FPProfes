package ar.org.fp.curso.profes.java;

//Declaración de clase
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    /**
     * Este método fue deprecado por Carlos, el 7/2/2024 por resultar inseguro,
     * usar en su reemplazo Auto(String marca, String modelo, String color)
     */
    @Deprecated
    Auto(){
        //constructor vacio
    }

    //constructor
    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }

    //métodos
    void acelerar(){                                                //acelerar
        velocidad+=10;
        if(velocidad>100) velocidad=100;
    }

    //método con ingreso de parámetros de entrada
    //método sobrecargado
    /**
     * Método para acelerar un auto.
     * @param kilometros cantidad de kilometros a acelerar
     */
    void acelerar(int kilometros){                                  //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }

    void acelerar(int kilometros, boolean turbo){                   //acelerarIntBolean

    }

    void frenar(){
        velocidad-=10;
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    int getVelocidad(){
        return velocidad;
    }

    String getEstado(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }

    //Método toString
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }

}//end class
