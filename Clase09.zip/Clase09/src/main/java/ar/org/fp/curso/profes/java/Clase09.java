package ar.org.fp.curso.profes.java;

import javax.swing.JOptionPane;

public class Clase09 {
    public static void main(String[] args) {
        System.out.println("Clase 09 - Paradigma de Objetos");
        System.out.println("Versión de java: "+System.getProperty("java.version"));

        /*
         * Que es una clase: una clase se encuentra como sustantivos en la vida real, 
         *      se escribe en singular iniciando en mayúscula. Ej Auto, Alumno, Profesor, Vendedor, Articulo
         * 
         * Que son los atributos: los atributos son variables contenidas dentro de la clase y 
         *      describen a la clase, tienen un tipo de datos.
         * 
         * Que son los métodos: los métodos son acciones que realiza una clase y se expresan como verbos
         * 
         * Que son los objetos: son instancias de la clase que representan una situación en particular
         *      y tienen estado propio.
         * 
         * Desacoplamiento(deseado) y cohesión de clases(deseado) 
         * Acoplamniento(no deseado)
         * 
         * Constructores: son métodos que se usan para inicializar un objeto, pueden existir varios
         *      constructores sobrecargados, Tienen el nombre nombre que la clase, no tiene devolución de valor.
         *      Si la clase no tiene constructor, java agrega un constructor vacio en tiempo de compilación
         */
 
        System.out.println("-- auto1 --");
        Auto auto1 = new Auto();        //new Auto() llama al constructor de la clase y crea un objeto
        auto1.marca="Ford";
        auto1.modelo="Ka";
        auto1.color="Rojo";
        auto1.acelerar();                   //10
        auto1.acelerar();                   //20
        auto1.acelerar();                   //30
        auto1.frenar();                     //20
        auto1.acelerar(12);      //32
        auto1.acelerar(26);      //48
        
        

        //imprimimos el estado del objeto (estado es el valor de sus atributos)
        System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);

        //Las variables deben ser inicializadas.
        //Los atributos se inicializan automaticamente.

        //String nombre;
        //int edad;
        //System.out.println(nombre+", "+edad);     //error las variables deben ser inicializadas


        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="VW";
        auto2.modelo="Gol";
        auto2.color="Blanco";

        for(int a=0; a<=60; a++) auto2.acelerar();
        //auto2.velocidad=3000;

        System.out.println(auto2.marca+", "+auto2.modelo+", "+auto2.color+", "+auto2.velocidad);

        auto2.imprimirVelocidad();
        System.out.println(auto2.getVelocidad());

        //JOptionPane.showMessageDialog(null, "Hola a todos");
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto2.getVelocidad());
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto2.velocidad);


        Cuenta cuentaCarlosRios=new Cuenta();
        cuentaCarlosRios.numero=1;
        cuentaCarlosRios.moneda="arg$";
        cuentaCarlosRios.depositar(300000);
        //cuentaCarlosRios.saldo=9999999999999L;

        System.out.println(cuentaCarlosRios.numero+", "+cuentaCarlosRios.moneda+", "+cuentaCarlosRios.getSaldo());

        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Peugeot", "208", "Gris");
        auto3.acelerar(23);
        System.out.println(auto3.getEstado());
        System.out.println(auto3.toString());
        System.out.println(auto3);

        //TODO reflectividad
        //TODO Java Bean (getters setters encapsulamiento)
        //TODO Loombox (aspectos)

    }
}
