package ar.org.fp.curso.profes.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase09Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase09Application.class, args);
	}

}
