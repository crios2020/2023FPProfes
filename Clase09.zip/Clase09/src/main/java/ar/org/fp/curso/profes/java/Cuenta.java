package ar.org.fp.curso.profes.java;

public class Cuenta {

    int numero;
    String moneda;
    private double saldo;

    void depositar(double monto){
        saldo+=monto;
        //imprimir ticket
    }

    public double getSaldo(){
        return saldo;
    }

}
