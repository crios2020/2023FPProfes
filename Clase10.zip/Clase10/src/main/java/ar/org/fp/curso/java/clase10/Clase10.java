package ar.org.fp.curso.java.clase10;

import javax.swing.JOptionPane;

/**
 * Esta es la clase principal del proyecto
 */
public class Clase10 {
    /**
     * Este es el punto de entrada del proyecto
     * @param args argumentos que ingresan por consola
     */
    public static void main(String[] args) {

        //Comentario de una sola linea, el usuario final no puede ver este comentario
        
        /*
          bloque
          de 
          comentarios
          el usuario final no puede ver este comentario
        */
        
        //TODO tarea pendiente, sirve para administrar el proyecto

        /**
         * comentario Java DOC
         * este comentario debe colocarse delante de la declaración de método o clase
         * el usuario final puede ver este comentario
         */


        //El lenguaje unificado de modelado (UML, por sus siglas en inglés, Unified Modeling Language) 

        //JOptionPane.showMessageDialog(null, "Clase 10");

        //Java DOC
        
        // .JAR
        // en la terminal, ejecutar: mvnw package

        //reflectividad
 /*
         * Que es una clase: una clase se encuentra como sustantivos en la vida real, 
         *      se escribe en singular iniciando en mayúscula. Ej Auto, Alumno, Profesor, Vendedor, Articulo
         * Clases en Java: son instancias de la clase java.lang.Class
         * 
         * 
         * Que son los atributos: los atributos son variables contenidas dentro de la clase y 
         *      describen a la clase, tienen un tipo de datos.
         * Atributos en Java: son instancias de la clase java.lang.reflect.Field
         * 
         * Que son los métodos: los métodos son acciones que realiza una clase y se expresan como verbos
         * Métodos en Java: son instancias de la clase java.lang.reflect.Method
         * 
         * Que son los objetos: son instancias de la clase que representan una situación en particular
         *      y tienen estado propio.
         * 
         * Desacoplamiento(deseado) y cohesión de clases(deseado) 
         * Acoplamniento(no deseado)
         * 
         * Constructores: son métodos que se usan para inicializar un objeto, pueden existir varios
         *      constructores sobrecargados, Tienen el nombre nombre que la clase, no tiene devolución de valor.
         *      Si la clase no tiene constructor, java agrega un constructor vacio en tiempo de compilación
         * constructores en java: son instancias de la clase java.lang.reflect.Constructor
         * 
         */
 

        //Java Bean (getters setters encapsulamiento)
        Empleado empleado=new Empleado(1, "Juan Perez", 550000);
        //empleado.sueldoBasico=4000000;
        empleado.setSueldoBasico(4000000);
        System.out.println(empleado);


        //Loombox (aspectos)

        Proveedor proveedor=new Proveedor(1,"Articulos Libreria","343434");
        proveedor.setTelefono("787878");
        System.out.println(proveedor);

    }
}
