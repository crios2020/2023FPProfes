package ar.org.fp.curso.java.entities;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public class ClientePersona {

    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;

    // Los clientes pueden crearse sin cuenta y despues se agrega
    // public ClientePersona(int nro, String nombre, int edad){
    //     this.nro = nro;
    //     this.nombre = nombre;
    //     this.edad = edad;
    // }

    // public void setCuenta(Cuenta cuenta) {
    //     this.cuenta = cuenta;
    // }

    // Un cliente siempre tiene cuenta, un cliente se crea con una cuenta
    // Una cuenta puede pertenecer a mas de un cliente
    public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta){
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = cuenta;
    }
    
    // Un cliente siempre tiene cuenta, un cliente se crea con una cuenta
    // Una cuenta solo se le crea y pertenece a un solo cliente
    public ClientePersona(int nro, String nombre, int edad, int nroCuenta, String moneda){
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = new Cuenta(nroCuenta, moneda);
    }

    //public void cambiarCuenta(int nroCuenta, String moneda){
    //    this.cuenta = new Cuenta(nroCuenta, moneda);
    //}

}

