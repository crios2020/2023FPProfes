package ar.org.fp.curso.java.test;

import ar.org.fp.curso.java.entities.ClientePersona;
import ar.org.fp.curso.java.entities.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        //Test de Objetos Mocks (Objetos Simulados)

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(450000);
        cuenta1.depositar(730000);
        cuenta1.debitar(240000);
        System.out.println(cuenta1);

        System.out.println("-- clienteConyugue1 --");
        //Cuenta cuentaContugues = new Cuenta(2,"args");
        ClientePersona clienteConyugue1 = new ClientePersona(2, "Marcos", 40, new Cuenta(10,"args"));
        clienteConyugue1.getCuenta().depositar(500000);
        System.out.println(clienteConyugue1);

        System.out.println("-- clienteConyugue2 --");
        ClientePersona clienteConyugue2 = new ClientePersona(1, "Claudia", 40, clienteConyugue1.getCuenta());
        clienteConyugue2.getCuenta().debitar(200000);
        System.out.println(clienteConyugue2);
        System.out.println(clienteConyugue1);

        System.out.println("-- cliente3 --");
        ClientePersona cliente3 = new ClientePersona(3, "Victor", 50, 3, "arg$");
        cliente3.getCuenta().depositar(50000);
        cliente3.getCuenta().debitar(20000);
        System.out.println(cliente3);

    }
}
