package ar.org.fp.curso.java.clase10;

public class Empleado {
    
    private int nroLegajo;
    private String nombre;
    private double sueldoBasico;
    
    public Empleado(int nroLegajo, String nombre, double sueldoBasico) {
        this.nroLegajo = nroLegajo;
        this.nombre = nombre;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public String toString() {
        return "Empleado [nroLegajo=" + nroLegajo + ", nombre=" + nombre + ", sueldoBasico=" + sueldoBasico + "]";
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public void setNroLegajo(int nroLegajo) {
        this.nroLegajo = nroLegajo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

    public void setSueldoBasico(double sueldoBasico) {
        this.sueldoBasico = sueldoBasico;
    }    

}
