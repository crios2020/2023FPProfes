package ar.org.fp.curso.java.clase10;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//@Getter
//@Setter
//@ToString
@AllArgsConstructor
@Data
public class Proveedor {   
    private int nroProveedor;
    private String nombre;
    private String telefono;
}
