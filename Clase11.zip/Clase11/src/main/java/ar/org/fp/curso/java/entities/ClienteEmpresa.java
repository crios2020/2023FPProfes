package ar.org.fp.curso.java.entities;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public class ClienteEmpresa {

    private int nro;
    private String razonSocial;
    private String direccion;
    //private Cuenta[] cuentas;
    private List<Cuenta> cuentas;

    public ClienteEmpresa(int nro, String razonSocial, String direccion) {
        this.nro = nro;
        this.razonSocial = razonSocial;
        this.direccion = direccion;
        this.cuentas = new ArrayList();
    }

    public void comprar(){
        System.out.println("Realizando compra");
    }

}
