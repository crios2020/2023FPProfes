package ar.org.fp.curso.java.entities;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public final class Cuenta {
    /*
     * una clase final, es una clase sellada, se pueden crear objetos de la clase,
     * pero no se pueden crear clases hijas
     */
    private int nro;
    private String moneda;
    private double saldo;

    public Cuenta(int nro, String moneda) {
        this.nro = nro;
        this.moneda = moneda;
    }

    public synchronized void depositar(double monto){
        if(monto >=10000000000L){
            System.out.println("deposito demasiado grande!");
        }else{
            saldo+=monto;
        }
        
    }

    public synchronized void debitar(double monto){
        if(saldo>=monto) saldo-=monto;
        else System.out.println("Saldo insuficiente!");
    }
    
}
