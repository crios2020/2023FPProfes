package ar.org.fp.curso.java.entities;

// public class CuentaTrucha extends Cuenta{
//     CuentaTrucha(int nro, String moneda){
//         super(nro, moneda);
//     }

//     @Override
//     public synchronized void depositar(double monto) {
//         super.depositar(monto*10);
//     }
    
// }
