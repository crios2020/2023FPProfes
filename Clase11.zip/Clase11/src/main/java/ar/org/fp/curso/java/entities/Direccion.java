package ar.org.fp.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Direccion {

    private String calle;
    private int nro;
    private String piso;
    private String depto;
    private String ciudad;

    /**
     * Constructor para direcciones de Ciudad Autonoma de Buenos Aires
     */
    public Direccion(String calle, int nro, String piso, String depto) {
        this.calle = calle;
        this.nro = nro;
        this.piso = piso;
        this.depto = depto;
        this.ciudad = "CABA";
    }

}
