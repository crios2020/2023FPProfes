package ar.org.fp.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public abstract class Persona {

    /*
     * una clase abstracta no permite crear objetos de la misma, si puedo 
     * crear clases hijas y objetos de clases hijas
     */

    private String nombre;
    private int edad;
    private Direccion direccion;

    public abstract void saludar();
    /*
     * un método abstracto solo puede existir en una clase abstracta.
     * es un método que debe ser implementado en las clases hijas.
     */

}
