package ar.org.fp.curso.java.test;

import ar.org.fp.curso.java.entities.Cliente;
import ar.org.fp.curso.java.entities.Cuenta;
import ar.org.fp.curso.java.entities.Direccion;
import ar.org.fp.curso.java.entities.Persona;
import ar.org.fp.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(450000);
        cuenta1.depositar(730000);
        cuenta1.debitar(240000);
        System.out.println(cuenta1);

        System.out.println("-- direccionVacia --");
        //Direccion direccionVacia = new Direccion();

        System.out.println("-- direccion1 --");
        Direccion direccion1 = new Direccion("Belgrano",49,null,null,"Moron");
        System.out.println(direccion1);

        System.out.println("-- direccion2 --");
        Direccion direccion2 = new Direccion("Perette", 770, "5", null);
        System.out.println(direccion2);

        //System.out.println("-- persona1 --");
        //Persona persona1 = new Persona("Juan", 28, direccion1);
        //System.out.println(persona1);

        System.out.println("-- vendedor1 --");
        Vendedor vendedor1 = new Vendedor("Andrea", 26, direccion2, 1, 850000);
        vendedor1.saludar();
        System.out.println(vendedor1);

        System.out.println("-- cliente1 --");
        Cliente cliente1 = new Cliente("Pedro",34,direccion1,1,cuenta1);
        cliente1.getCuenta().depositar(400000);
        cliente1.saludar();
        System.out.println(cliente1);
     
        //Clase Object
        Object obj=3;
        obj="Hola";
        obj=cliente1;

        //Polimorfismo
        System.out.println("-- poliformismo --");
        Persona persona1=new Vendedor("Laura", 60, direccion2, 2, 2);
        Persona persona2=new Cliente("Ana", 50, direccion2, 2, cuenta1);
        persona1.saludar();
        persona2.saludar();

        Vendedor vendedorX=(Vendedor)persona1;
        Vendedor vendedorY=(persona1 instanceof Vendedor)?(Vendedor)persona1:null;

        System.out.println("Reflection");
        System.out.println(vendedorX);
        System.out.println(vendedorX.getClass());
        System.out.println(vendedorX.getClass().getName());
        System.out.println(vendedorX.getClass().getSimpleName());
        System.out.println(vendedorX.getClass().getSuperclass().getName());
        System.out.println(vendedorX.getClass().getSuperclass().getSuperclass().getName());
        System.out.println(
                            vendedorX
                                    .getClass()
                                    .getSuperclass()
                                    .getSuperclass()
                                    .getSuperclass()
                        );
        String texto="Hola";
        System.out.println(texto.getClass().getName());
        System.out.println(texto.getClass().getSuperclass().getName());

        //Para el lunes
        //TODO  Interfaces
        //TODO  Default
        //TODO  Static
        //TODO  Collection
        //TODO  Api Stream
    }
}
