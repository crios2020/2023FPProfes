package ar.org.fp.curso.java.test;

import java.util.List;

import ar.org.fp.curso.java.entities.ClienteEmpresa;
import ar.org.fp.curso.java.entities.ClientePersona;
import ar.org.fp.curso.java.entities.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        //Test de Objetos Mocks (Objetos Simulados)

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(450000);
        cuenta1.depositar(730000);
        cuenta1.debitar(240000);
        System.out.println(cuenta1);

        System.out.println("-- clienteConyugue1 --");
        //Cuenta cuentaContugues = new Cuenta(2,"args");
        ClientePersona clienteConyugue1 = new ClientePersona(2, "Marcos", 40, new Cuenta(10,"args"));
        clienteConyugue1.getCuenta().depositar(500000);
        System.out.println(clienteConyugue1);

        System.out.println("-- clienteConyugue2 --");
        ClientePersona clienteConyugue2 = new ClientePersona(1, "Claudia", 40, clienteConyugue1.getCuenta());
        clienteConyugue2.getCuenta().debitar(200000);
        System.out.println(clienteConyugue2);
        System.out.println(clienteConyugue1);

        System.out.println("-- cliente3 --");
        ClientePersona cliente3 = new ClientePersona(3, "Victor", 50, 3, "arg$");
        cliente3.getCuenta().depositar(50000);
        cliente3.getCuenta().debitar(20000);
        cliente3.comprar();
        System.out.println(cliente3);

        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1 = new ClienteEmpresa(1, "Todo Motores", "Lima 222");
        List<Cuenta> lista = clienteEmpresa1.getCuentas();
        lista.add(new Cuenta(20, "arg$"));              //0
        lista.add(new Cuenta(21, "reales"));            //1
        lista.add(new Cuenta(22, "U$S"));               //2

        //lista.remove(1);
        lista.get(0).depositar(560000);
        lista.get(0).depositar(1200000);
        lista.get(0).debitar(352000);
        lista.get(1).depositar(89000);
        lista.get(2).depositar(12500);
        lista.stream().filter(c->c.getNro()==22).findAny().get().depositar(135);

        clienteEmpresa1.comprar();
        System.out.println(clienteEmpresa1);



    }
}
