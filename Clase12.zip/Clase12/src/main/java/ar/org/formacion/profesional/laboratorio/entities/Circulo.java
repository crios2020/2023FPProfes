package ar.org.formacion.profesional.laboratorio.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
public class Circulo extends Figura {
    
    private double radio;

    @Override
    public String getEstado() {
        //return "Base: "+base+", Altura: "+altura;
        return this.toString();
    }

    @Override
    public double getPerimetro() {
        return Math.PI*radio*2;
    }

    @Override
    public double getSuperficie() {
        return Math.PI*Math.pow(radio, 2);
    }

    

}
