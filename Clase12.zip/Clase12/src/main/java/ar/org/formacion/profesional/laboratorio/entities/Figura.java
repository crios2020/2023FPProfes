package ar.org.formacion.profesional.laboratorio.entities;

public abstract class Figura {
    public abstract double getPerimetro();
    public abstract double getSuperficie();
    public abstract String getEstado();
}
