package ar.org.formacion.profesional.laboratorio.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
public class Triangulo extends Figura{
    
    private double base;
    private double altura;

    @Override
    public String getEstado() {
        //return "Base: "+base+", Altura: "+altura;
        return this.toString();
    }

    @Override
    public double getPerimetro() {
        return base + altura + Math.hypot(base, altura);
    }

    @Override
    public double getSuperficie() {
        return base * altura / 2;
    }

}
