package ar.org.formacion.profesional.laboratorio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaboratorioApplicationTests {

	@Test
	void contextLoads() {
	}

}
