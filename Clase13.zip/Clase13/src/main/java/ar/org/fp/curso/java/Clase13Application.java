package ar.org.fp.curso.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase13Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase13Application.class, args);
	}

}
