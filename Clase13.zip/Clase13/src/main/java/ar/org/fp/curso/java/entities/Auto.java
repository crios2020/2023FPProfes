package ar.org.fp.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public class Auto {
    private String marca;
    private String modelo;
    private String color;
    private static int velocidad;

    public static void acelerar(){
        velocidad+=10;
    }

    public static void frenar(){
        velocidad-=10;
    }

    public static int getVelocidad(){
        return velocidad;
    }
    
}
