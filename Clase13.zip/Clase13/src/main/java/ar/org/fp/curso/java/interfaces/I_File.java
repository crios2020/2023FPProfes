package ar.org.fp.curso.java.interfaces;

public interface I_File {
    /*
     * Una interface:
     *      - no tiene atributos.
     *      - no tiene constructores.
     *      - puede tener atributos constantes (final) o estaticos (static)
     *      - no tiene miembros private o protected.
     *      - los métodos son abstractos y publicos.
     *      - una clase puede implementar muchas interfaces.
     */

    /**
     * Método para escribir el archivo
     * @param text texto a escribir
     */
    void setText(String text);
    
    /**
     * Método para leer el archivo
     * @return retorna  el texto del archivo
     */
    String getText();

    /*
     * Interfaces en Java 8 o sup.
     * Métodos default: son métodos que tienen cuerpo (no abstractos)
     * y una clase puede heredar métodos default de muchas interfaces
     */
    default void info(){
        System.out.println("Inteface I_File");
    }

}
