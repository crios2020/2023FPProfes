package ar.org.fp.curso.java.test;

import java.io.FileReader;

public class TestExpcetion {
    public static void main(String[] args) {

        // try{
        //     System.out.println(10/1);
        //     System.out.println("Esta linea no se ejecuta!");
        // }catch(Exception e){
        //     System.out.println("Ocurrio un problema");
        //     System.out.println(e);
        // }
        // System.out.println("El programa termina normalmente!");

   

        // try {
        //     FileReader in=new FileReader("texto.txt");
        //     System.out.println(in.read());
        //     in.close();
        // } catch (Exception e) {
        //     System.out.println(e);
        // }

        // Try with resources JDK 7 o sup
        try (FileReader in=new FileReader("texto.txt")){
            System.out.println(in.read());
        } catch (Exception e) {
            System.out.println(e);
        }

        
    }
}
