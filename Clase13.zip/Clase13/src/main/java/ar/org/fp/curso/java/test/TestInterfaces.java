package ar.org.fp.curso.java.test;

import java.util.Scanner;

import ar.org.fp.curso.java.interfaces.I_File;
import ar.org.fp.curso.java.utils.FileBinary;
import ar.org.fp.curso.java.utils.FileCloud;
import ar.org.fp.curso.java.utils.FileText;

public class TestInterfaces {
    public static void main(String[] args) throws Exception{
        
        //Declaración de interface
        I_File file = null;

        //Inicialización
        //file = new FileText();
        //file = new FileBinary();
        //file = new FileCloud();

        System.out.println("Ingrese 'FileText' o 'FileBinary' o FileCloud");
        String in=new Scanner(System.in).nextLine();

        //if(in.equalsIgnoreCase("FileText"))     file = new FileText();
        //if(in.equalsIgnoreCase("FileBinary"))   file = new FileBinary();
        //if(in.equalsIgnoreCase("FileCloud"))    file = new FileCloud();

        //file = (I_File)Class
        //            .forName("ar.org.fp.curso.java.utils."+in)
        //            .newInstance();
        
        file = (I_File)Class
                        .forName("ar.org.fp.curso.java.utils."+in)
                        .getConstructor()
                        .newInstance();

        //app Test
        file.setText("Hola");
        System.out.println(file.getText());
        file.info();

    }
}
