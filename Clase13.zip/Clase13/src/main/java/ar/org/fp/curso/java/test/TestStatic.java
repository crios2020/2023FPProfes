package ar.org.fp.curso.java.test;

import ar.org.fp.curso.java.entities.Auto;

public class TestStatic {
    public static void main(String[] args) {
        System.out.println("Hola");

        Auto.acelerar();        //10
        System.out.println("-- auto1 --");
        Auto auto1 = new Auto("Fiat","Idea","Gris");
        auto1.acelerar();       //20
        System.out.println(auto1+" "+auto1.getVelocidad());

        System.out.println("-- auto2 --");
        Auto auto2 = new Auto("Ford", "Mondeo", "Bordo");
        auto2.acelerar();       //30
        System.out.println(auto2+" "+auto2.getVelocidad());     //30
        System.out.println(auto1+" "+auto1.getVelocidad());     //30

        Auto.acelerar();
        System.out.println(Auto.getVelocidad());

    }
}
