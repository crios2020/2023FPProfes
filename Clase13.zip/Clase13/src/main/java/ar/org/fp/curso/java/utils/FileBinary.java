package ar.org.fp.curso.java.utils;

import ar.org.fp.curso.java.interfaces.I_File;

public class FileBinary implements I_File{

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo Binario!");
    }

    @Override
    public String getText() {
        return "Archivo Binario";
    }
    
}
