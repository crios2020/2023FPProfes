package ar.org.fp.curso.java;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase14Application {

	public static void main(String[] args) {
		//SpringApplication.run(Clase14Application.class, args);

		//Clase 14 Frameworks Collections


		//Array - Vector
		Auto[] autos=new Auto[4];

		autos[0]=new Auto("Fiat", "Uno", "Rojo");
		autos[1]=new Auto("Renault", "12", "Negro");
		autos[2]=new Auto("Chevrolet","Corsa","Gris");
		autos[3]=new Auto("VW","Gol","Blanco");

		//recorrido por indices
		//for(int a=0; a<autos.length; a++){
		//	System.out.println(autos[a]);
		//}

		//recorrido forEach
		for(Auto auto : autos) System.out.println(auto);

		//Interface List: Representa un vector dinamico con indices
		List lista1=new ArrayList();
		//List lista1=new LinkedList();
		//List lista1=new Vector();

		lista1.add(new Auto("Peugeot","206","Rojo"));			//0
		lista1.add(new Auto("Renault","Clio","Negro"));			//1
		lista1.add(new Auto("Volvo","456","Azul"));				//2
		lista1.add("hola");															//3
		lista1.add("Mundo!");														//5
		lista1.add(22);																//6
		lista1.add(4, "Java");														//4
		//lista1.remove(6);

		//copiar los autos del array autos a lista1
		for(Auto auto : autos) lista1.add(auto);

		//recorrido por indices
		System.out.println("*********************************************************");
		// for(int a=0; a<lista1.size(); a++){
		// 	System.out.println(lista1.get(a));
		// }

		//recorrido forEach
		//for(Object o : lista1) System.out.println(o);

		//método .forEach()		JDK 8 o sup
		//lista1.forEach(o->System.out.println(o));
		// lista1.forEach(o->{
		// 	System.out.print("* ");
		// 	System.out.println(o);
		// });
		lista1.forEach(System.out::println);

		//Uso de Generics <>	JDK 5
		List<Auto> lista2=new ArrayList();
		lista2.add(new Auto("Ford","Mondeo","Rojo"));
		lista2.add(new Auto("Fiat", "Idea", "Azul"));
		lista2.add(new Auto("Fiat", "Idea", "Azul"));
		//lista2.add("Hola");

		//copiar los autos de lista1 a lista2
		lista1.forEach(o->{ if( o instanceof Auto) lista2.add((Auto)o);	});
		System.out.println("*********************************************************");
		lista2.forEach(System.out::println);	
		System.out.println("Longitud de lista2: "+lista2.size());

		Auto auto1=lista2.get(0);
		Auto auto2=(Auto)lista1.get(0);

		//Interface Set:	Representa una lista sin indices, 
		//					el mismo elemento almacenado es el indice.
		//					El set no permite valores duplicados

		Set<String>semana;

		//Implementación HashSet: es la más veloz, pero no tiene garantizado 
		//							el orden de los elementos.
		//semana=new HashSet();

		//Implementación LinkedHashSet:	almacena elementos en una lista enlazada
		//								por orden de ingreso
		//semana= new LinkedHashSet();

		//Implementación TreeSet:	almacena elementos en un arbol, por orden natural
		semana=new TreeSet();

		//app
		semana.add("Lunes");
		semana.add("Martes");
		semana.add("Miércoles");
		semana.add("Jueves");
		semana.add("Viernes");
		semana.add("Sábado");
		semana.add("Domingo");
		semana.add("Lunes");
		semana.add("Lunes");
		semana.add("Martes");
		semana.forEach(System.out::println);
		
		//Set<Auto>setAutos=new LinkedHashSet();
		Set<Auto>setAutos=new TreeSet();
		setAutos.add(new Auto("Porshe","911","Negro"));
		setAutos.add(new Auto("VW","Gol","Blanco"));
		setAutos.addAll(lista2);
		setAutos.add(new Auto("Fiat", "Idea", "Amarillo"));
		setAutos.add(new Auto("Fiat", "Idea", "Verde"));
		setAutos.add(new Auto("Fiat", "Idea", "Gris"));
		setAutos.add(new Auto("Fiat", "Idea", "Rojo"));
		setAutos.add(new Auto("Fiat", "Idea", "Blanco"));

		System.out.println("******************************************");
		//setAutos.forEach(System.out::println);
		setAutos.forEach(auto->System.out.println(auto+" : "+auto.hashCode()));
		
	}

}
