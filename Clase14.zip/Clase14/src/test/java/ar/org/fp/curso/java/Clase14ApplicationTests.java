package ar.org.fp.curso.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
