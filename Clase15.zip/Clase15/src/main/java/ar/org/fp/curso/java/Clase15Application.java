package ar.org.fp.curso.java;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase15Application {

	// datalist
	private static List<Persona> personas = new ArrayList();

	public static void main(String[] args) {
		// SpringApplication.run(Clase15Application.class, args);

		cargarDatos();

		imprimir();

		separador();

		//Api Stream
		//select * from personas
		//personas.forEach(System.out::println);
		personas.stream().forEach(System.out::println);

		separador();
		//select * from personas where nombre='beatriz';

		// for(Persona p: personas){
		// 	if(p.getNombre().equalsIgnoreCase("beatriz")){
		// 		System.out.println(p);
		// 	}
		// }

		personas
				.stream()
				.filter(p->p.getNombre().equalsIgnoreCase("beatriz"))
				.forEach(System.out::println);

		separador();
		//select * from personas where nombre like 'la%';
		personas
				.stream()
				.filter(p->p.getNombre().toLowerCase().startsWith("la"))
				.forEach(System.out::println);
			
		separador();
		//select * from personas where nombre like '%a';
		personas
			.stream()
			.filter(p->p.getNombre().toLowerCase().endsWith("a"))
			.forEach(System.out::println);	

		separador();
		//select * from personas where nombre like '%ar%';
		personas
			.stream()
			.filter(p->p.getNombre().toLowerCase().contains("ar"))
			.forEach(System.out::println);	
		
		//select * from personas where edad>=30;
		separador();
		personas
			.stream()
			.filter(p->p.getEdad()>=30)
			.forEach(System.out::println);	

		//select * from personas where nombre like 'la%' and edad>=30;
		separador();
		// personas
		// 	.stream()
		// 	.filter(p->p.getNombre().toLowerCase().startsWith("la")
		// 			&& p.getEdad()>=30)
		// 	.forEach(System.out::println);
		personas
				.stream()
				.filter(p->p.getNombre().toLowerCase().startsWith("la"))
				.filter(p->p.getEdad()>=30)
				.forEach(System.out::println);
		
		//select * from personas where nombre like 'la%' or edad>=30;		
		separador();
		personas
			.stream()
			.filter(p->p.getNombre().toLowerCase().startsWith("la")
					|| p.getEdad()>=30)
			.forEach(System.out::println);

		//select * from personas where nombre like 'la%o'
		separador();
		personas
			.stream()
			.filter(p->p.getNombre().toLowerCase().startsWith("la")
					&& p.getNombre().toLowerCase().endsWith("o"))
			.forEach(System.out::println);

		//select * from personas where edad between 30 and 40;
		separador();
		personas
		.stream()
		.filter(p->p.getEdad()>=30 && p.getEdad()<=40)
		.forEach(System.out::println);

		//orden natural
		separador();
		personas
				.stream()
				.sorted()
				.forEach(System.out::println);
		

		//select * from personas order by nombre;
		separador();
		personas
				.stream()
				.sorted(Comparator.comparing(Persona::getNombre))
				.forEach(System.out::println);

		//select * from personas order by apellido, nombre;
		separador();
		personas
			.stream()
			.sorted(
						Comparator.comparing(Persona::getApellido)
							.thenComparing(Persona::getNombre))
			.forEach(System.out::println);
		
		// personas
		// 		.stream()
		// 		.sorted(Comparator.comparing(Persona::getNombre))
		// 		.sorted(Comparator.comparing(Persona::getApellido))
		// 		.forEach(System.out::println);

		//select * from personas order by apellido desc, nombre;
		separador();
		personas
			.stream()
			.sorted(Comparator.comparing(Persona::getNombre))
			.sorted(Comparator.comparing(Persona::getApellido).reversed())
			.forEach(System.out::println);

		//select * from personas where edad>=30 order by apellido desc, nombre;
		separador();			
		// personas
		// 	.stream()
		// 	.filter(p->p.getEdad()>=30)
		// 	.sorted(Comparator.comparing(Persona::getNombre))
		// 	.sorted(Comparator.comparing(Persona::getApellido).reversed())
		// 	.forEach(System.out::println);
		personas
			.stream()
			.filter(p->p.getEdad()>=30)
			.sorted(
					Comparator.comparing(Persona::getApellido).reversed()
						.thenComparing(Persona::getNombre)
					)
			.forEach(System.out::println);

		//select max(edad) from personas
		separador();
		int edadMaxima=personas
						.stream()
						.max(Comparator.comparingInt(Persona::getEdad))
						.get()
						.getEdad();
		System.out.println("Edad Máxima: "+edadMaxima);

		//select * from personas where edad=(select max(edad) from personas);
		separador();
		//System.out.println(personas
		//						.stream()
		//						.max(Comparator.comparingInt(Persona::getEdad))
		//						.get()); //error

		personas
				.stream()
				.filter(p->p.getEdad()==(edadMaxima))
				.forEach(System.out::println);


	}

	private static void separador() {
		// Separator
		System.out.println("============================");
	}

	private static void imprimir() {
		// Impresión
		personas.forEach(System.out::println);
	}

	private static void cargarDatos() {
		// Ingreso de datos
		personas.add(new Persona("Laura", "Perez", 25));
		personas.add(new Persona("Ana", "Godoy", 35));
		personas.add(new Persona("Juan", "Perez", 25));
		personas.add(new Persona("Maria", "Parodi", 25));
		personas.add(new Persona("Carlos", "Perez", 18));
		personas.add(new Persona("Juan", "Gomnez", 50));
		personas.add(new Persona("Beatriz", "Garcia", 6));
		personas.add(new Persona("Laureano", "Garcia", 15));
		personas.add(new Persona("Lautaro", "Garcia", 63));
		personas.add(new Persona("La", "Garcia", 68));
		personas.add(new Persona("Lorena", "Garcia", 45));
		personas.add(new Persona("Leonardo", "Garcia", 13));
		personas.add(new Persona("lautaro", "Garcia", 33));
		personas.add(new Persona("Marta", "Garcia", 40));
		personas.add(new Persona("Omar", "Garcia", 30));
		personas.add(new Persona("Armando", "Garcia", 45));
		personas.add(new Persona("Laura", "Soto", 8));		//Laura,Soto,008
		personas.add(new Persona("Laura", "Soto", 12));	//Laura,Soto,012
		personas.add(new Persona("Armando", "Garcia", 68));
	}

}
